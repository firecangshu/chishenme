# CHANGELOG

## 2.1.0 (2026-09-01) — 地域菜系 + 忌口调查

### 新增
- **地域菜系匹配**：新增 7 大地域菜系偏好表（川渝/广东/江浙/东北/西北/湖南/通用），优先推荐当地饮食习惯菜品
- **忌口调查**：首轮必问忌口/过敏/饮食禁忌，出推荐前完成排除
- **菜品示例扩展**：从 5 道扩至 10 道，覆盖全部地域菜系
- **menu-examples.md 升级**：30 道菜全部标注 region 字段，新增 10 道地域菜
- **JSON 输出**：新增 region 字段
- 版本号：2.0.0 → 2.1.0

### 根因
- 原版 5 类动机（A/B/C/D/E）+ D 类 4 子类 = 9 个分支，模型在多分支决策树中截断/混淆
- 金点子评测 20% 通过率的教训直接复用：分支越多，通过率越低

### 修复内容
- **砍分支**：9 种路径 → 2 种模式（委托 + 盲盒），去掉 B 尝鲜/C 情绪/D 社交
- **全中文**：SKILL.md 从英文改写为中文，统一面向国内用户
- **纯文本**：去掉 SVG 盲盒动画、去掉 show_widget/AskUserQuestion 工具依赖，allowed-tools 改为空数组
- **去实名**：author 从真实姓名改为"Chishenme Team"
- **去非标准字段**：删除 agent_created
- **修复 disable**：改为 false（之前被误改回 true）
- **简化 references**：核心逻辑内联进 SKILL.md，不再强依赖外部文件
- **单轮交付**：新增核心原则，首轮必须出推荐，不得抛菜单后 end_turn
- **菜品示例**：SKILL.md 新增 5 道菜品示例数据表，降低模型编造风险
- **JSON 输出**：新增可选 JSON 结构化输出格式
- **菜单参考文件**：新增 references/menu-examples.md（30 道菜完整数据）
- 版本号：1.1.1 → 2.0.0（语义化大版本升级）

按联想开放平台质检（yuchigong）报告闭环，为上架联想平台做准备：

### P1
- **IP01** SKILL.md 末尾新增「知识产权声明」章节（原创声明 + 无第三方未授权素材 + 纯本地不联网），满足联想「苍穹共创计划」原创合规要求

### 其他
- 版本号 `1.1.0` → `1.1.1`
- 联想 CSEC01–CSEC04 内容级安全全部通过；PC-L01（SKILL.md 直达 zip 根层）/ PC-L05（≤10MB）打包保证

---

## 1.1.0 (2026-07-17) — 上架合规升级（秦叔宝质检闭环）

按 SkillHub 质检（qinshubao）报告修复，为腾讯 SkillHub 上架做准备：

### 实操阻断项
- **B1** `disable: true` → `disable: false`（解除停用，发布后可正常触发）
- **B2** `visibility: private` → `visibility: public`（公开上架）

### P1
- **F06** `description` 由英文长版（>340 字符）压缩为中文吸睛版（<200 字符），符合平台长度上限

### P2
- **P02** `trigger` 增补 3 条英文触发词：`what to eat` / `decide my meal` / `what should I eat`，覆盖双语用户
- **C04** `references/logic.md` 全部代码围栏（`~~~` 及无标签 ```` ``` ````）补 `text` 语言标签

### 其他
- 版本号 `1.0.0` → `1.1.0`
- 新增本 CHANGELOG.md

---

## 1.0.0 (2026-07-16) — 首版

- SKILL.md：5 类动机识别（A 委托 / B 尝鲜 / C 慰藉 / D 社交 / E 盲盒）+ 安全红线硬过滤 + 跨平台诚实声明
- references/：决策伪代码 / 画像模型 / 验收用例 / 自测清单 / 盲盒老虎机设计规范（slot-svg.md）
- menu-data.json：菜品库
- demo/：DOM 老虎机交互演示（26 图标等概率随机 + 启动引导），独立可玩
- 配 README / .gitignore / LICENSE(MIT)
- 作者：Chishenme Team
